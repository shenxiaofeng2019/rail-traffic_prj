#include "bsp_lsm303.h"
#include "bsp_iic1.h"
#include "lsm_queue.h"
#include <math.h>
//#include "delay.h"

unsigned char g_LSM_BUF[12];                     //???????
static int16_t acc_x,acc_y,acc_z;
static int16_t mag_x,mag_y,mag_z;

static float roll, pitch, yaw;
static float By2, Bz2, Bx3;

#define DEFAULT_QUEUE_NUM	(10)

void lsm303_MagInit(void)
{
//	??????,?????????????????0;??????????
	SlaveAddress=LSM303AGR_MAG_I2C_ADDRESS;
	
	while(WriteOneBytecheck(0x60,0x8c)!=1){}; //????3HZ?????????????0??,??????????
	while(WriteOneBytecheck(0x61,0x02)!=1){}; // ??????
	while(WriteOneBytecheck(0x62,0x10)!=1){};
	while(WriteOneBytecheck(0x61,0x02)!=1){};
}

void lsm303_magread(void)
{
		SlaveAddress=LSM303AGR_MAG_I2C_ADDRESS;
	  HAL_Delay(1);	
	  g_LSM_BUF[6]=IIC_ReadOneByte(LSM303_OUT_X_H_M);
	  g_LSM_BUF[7]=IIC_ReadOneByte(LSM303_OUT_X_L_M);
  	g_LSM_BUF[8]=IIC_ReadOneByte(LSM303_OUT_Y_H_M);
	  g_LSM_BUF[9]=IIC_ReadOneByte(LSM303_OUT_Y_L_M);
	  g_LSM_BUF[10]=IIC_ReadOneByte(LSM303_OUT_Z_H_M);
	  g_LSM_BUF[11]=IIC_ReadOneByte(LSM303_OUT_Z_L_M);
	
	mag_x = (g_LSM_BUF[7]<<8) | g_LSM_BUF[6];
	mag_y = (g_LSM_BUF[9]<<8) | g_LSM_BUF[8];
	mag_z = (g_LSM_BUF[11]<<8) | g_LSM_BUF[10];
}

void lsm303_AccInit(void)
{
	
	SlaveAddress=LSM303AGR_ACC_I2C_ADDRESS;	

	while(WriteOneBytecheck(0x21,0x00)!=1){};
	while(WriteOneBytecheck(0x22,0x00)!=1){};
	while(WriteOneBytecheck(0x23,0x81)!=1){};
	while(WriteOneBytecheck(0x20,0x57)!=1){};
		
	
}

void lsm303_accread(void)
{			

		SlaveAddress=LSM303AGR_ACC_I2C_ADDRESS;

	  HAL_Delay(1);
	  g_LSM_BUF[0]=IIC_ReadOneByte(LSM303_OUT_X_L_A);
	  g_LSM_BUF[1]=IIC_ReadOneByte(LSM303_OUT_X_H_A);
  	g_LSM_BUF[2]=IIC_ReadOneByte(LSM303_OUT_Y_L_A);
	  g_LSM_BUF[3]=IIC_ReadOneByte(LSM303_OUT_Y_H_A);
	  g_LSM_BUF[4]=IIC_ReadOneByte(LSM303_OUT_Z_L_A);
	  g_LSM_BUF[5]=IIC_ReadOneByte(LSM303_OUT_Z_H_A);


	acc_x = (g_LSM_BUF[1]<<8) | g_LSM_BUF[0];
	acc_y = (g_LSM_BUF[3]<<8) | g_LSM_BUF[2];
	acc_z = (g_LSM_BUF[5]<<8) | g_LSM_BUF[4];
	
	
}

void LSM303_Init()
{
	lsm303_AccInit();
	lsm303_MagInit();
	
	Init_LSMQueue(DEFAULT_QUEUE_NUM);
}

void LSM303_Read()
{
	lsm303_accread();
	lsm303_magread();
	
	Load_Data(g_LSM_BUF);
	
}
